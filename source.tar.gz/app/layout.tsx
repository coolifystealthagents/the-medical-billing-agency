import SiteNavigation from "@/components/SiteNavigation";
import type { Metadata } from 'next'; import Script from 'next/script'; import './globals.css'; import './october12.css'; import './service-detail.css'; import './marketing.css'; import {site} from '@/lib/site'; import Header from '@/components/Header'; import Footer from '@/components/Footer';
export const metadata:Metadata={metadataBase:new URL('https://'+site.domain),title:{default:site.brand,template:'%s | '+site.brand},description:site.intro,alternates:{canonical:'/'},robots:{index:true,follow:true}};
export default function RootLayout({children}:{children:React.ReactNode}){const org={'@context':'https://schema.org','@type':'Organization',name:site.brand,url:'https://'+site.domain,logo:'https://'+site.domain+'/logo.svg',sameAs:[]};const tracker="window.ACR_TRACKER_CONFIG={siteId:'"+site.dir+"',endpoint:'/ingest/track',debug:false};";const motion="const o=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');o.unobserve(x.target)}}));document.querySelectorAll('.reveal').forEach(x=>o.observe(x));";return <html lang="en"><head><script dangerouslySetInnerHTML={{__html:"document.documentElement.classList.add('js')"}}/></head><body className={site.variant} style={{'--bg':site.colors[1],'--ink':site.colors[0],'--accent':site.colors[2],'--metal':site.colors[3],'--paper':site.colors[1],'--display':site.fontDisplay,'--body':site.fontBody} as React.CSSProperties}><a className="skip" href="#main">Skip to content</a><SiteNavigation/><main id="main">{children}</main><Footer/><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(org)}}/><Script id="acr-config" strategy="beforeInteractive" dangerouslySetInnerHTML={{__html:tracker}}/><Script src="https://acrtracking.stealthagents.us/v1/tracker.js" strategy="afterInteractive"/>
        <Script
          id="databull-analytics"
          src="https://databull.stealthagents.us/js/script.js"
          data-website-id="dc_ucw24v9os168w0"
          data-domain="themedicalbillingagency.com"
          strategy="afterInteractive"
        /><Script id="motion" strategy="afterInteractive" dangerouslySetInnerHTML={{__html:motion}}/></body></html>}

import "./refinement.css";

import "./contact-fonts.css";
import "./contact-experience.css";
