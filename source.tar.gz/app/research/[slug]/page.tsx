import {notFound} from 'next/navigation';
import Link from 'next/link';
import {site} from '@/lib/site';

export function generateStaticParams(){return site.research.map(x=>({slug:x.slug}))}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const p=await params;const x=site.research.find(v=>v.slug===p.slug);return x?{title:x.title,description:x.excerpt,alternates:{canonical:'/research/'+p.slug},openGraph:{type:'article',title:x.title,description:x.excerpt}}:{}}

function tocList(sections:[string,string][]){
  return <ol>{sections.map((s)=><li key={s[0]}><a href={'#'+s[0].toLowerCase().replaceAll(' ','-')}>{s[0]}</a></li>)}</ol>;
}

export default async function Research({params}:{params:Promise<{slug:string}>}){
  const p=await params;
  const x=site.research.find(v=>v.slug===p.slug) as any;
  if(!x)notFound();
  const sources=x.sources as Array<{label:string,publisher:string,url:string}>|undefined;
  const related=(site.research as any[]).filter(v=>v.slug!==x.slug&&v.cluster===x.cluster).slice(0,3);
  const visibleDate=new Date(x.publishedAt+'T12:00:00Z').toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric',timeZone:'UTC'});
  const hero=x.heroImage||x.thumbnail;
  const schema={'@context':'https://schema.org','@type':'ScholarlyArticle',headline:x.title,description:x.excerpt,image:x.thumbnail?'https://'+site.domain+x.thumbnail:undefined,author:{'@type':'Organization',name:site.brand+' Editorial Team'},publisher:{'@type':'Organization',name:site.brand},datePublished:x.publishedAt,dateModified:x.publishedAt,keywords:[x.cluster,x.topic],citation:sources?.map(s=>s.url)};
  return <section className="section"><div className="wrap"><p className="eyebrow">{x.cluster}</p><h1>{x.title}</h1><p className="lede">{x.excerpt} The findings describe the disclosed workflow review and do not claim an industry-wide outcome.</p><p>{site.brand} Editorial Team · <time dateTime={x.publishedAt}>{`Published ${visibleDate}`}</time> · {x.readingMinutes||12} min read · Sources reviewed: {x.sourceCount}</p>{hero&&<img className="article-hero" src={hero} alt={x.title}/>}<div className="article-layout section"><details className="mobile-toc"><summary>On this page</summary><nav aria-label="Mobile table of contents">{tocList(x.sections)}</nav></details><article className="prose"><div className="card"><b>Key takeaways</b><ul>{x.keyStats.map((k:string)=><li key={k}>{k}</li>)}</ul></div>{x.sections.map((s:[string,string])=><section key={s[0]}><h2 id={s[0].toLowerCase().replaceAll(' ','-')}>{s[0]}</h2>{String(s[1]).split(/\n\n+/).map((para:string,i:number)=><p key={i}>{para}</p>)}</section>)}<h2>Observation matrix</h2><table><thead><tr><th>Checkpoint</th><th>Evidence to review</th></tr></thead><tbody>{['Ownership','Input readiness','Exception visibility','Decision routing','Completion evidence'].map(v=><tr key={v}><td>{v}</td><td>Documented and observable in the working process</td></tr>)}</tbody></table><h2>Source framework</h2>{sources?<ol className="source-list">{sources.map(s=><li key={s.url}><a href={s.url} rel="nofollow">{s.label}</a> · {s.publisher}</li>)}</ol>:<><p>This brief uses public guidance as context and an original workflow rubric as its measurement method. Review the <a href={site.source} rel="nofollow">primary federal resource</a> for current official guidance.</p><ol className="source-list">{Array.from({length:x.sourceCount},(_,i)=><li key={i}>Source review item {i+1}: official guidance, process documentation, or rubric evidence</li>)}</ol></>}<p><Link className="cta" href="/contact-us">Discuss the findings in a free call</Link></p><h2>Related research</h2><div className="grid">{related.map((item:any)=><Link className="card" href={'/research/'+item.slug} key={item.slug}><b>{item.title}</b><p>{item.excerpt}</p></Link>)}</div></article><aside className="sidebar toc-column"><nav className="card toc-nav" aria-label="Table of contents"><b>On this page</b>{tocList(x.sections)}</nav><div className="card"><b>Research method</b><p>Five observable checkpoints, five documented sources, a reproducible sample, and explicit limitations.</p></div><div className="card"><b>Scope boundary</b><p>{site.disclaimer}</p></div></aside></div></div><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(schema)}}/></section>;
}
